var searchData=
[
  ['generate_5freport',['generate_report',['../classSimulator.html#aac997ccfa238ee53bfa997570ced2fc2',1,'Simulator']]],
  ['getcategory_5f',['getCategory_',['../classTrack.html#af53a14954e7ca97df3570a2420a77786',1,'Track']]],
  ['getcorrelated_5ftrack_5fid',['getCorrelated_track_id',['../classTrack.html#acd6e6e6647bb07ee85ecd2fad28c412f',1,'Track']]],
  ['getdistance_5f',['getDistance_',['../classTrack.html#a18cd5d18154b7ac8c8d165f8fa7c8159',1,'Track']]],
  ['getidentity_5f',['getIdentity_',['../classTrack.html#a77f2645a628e3ef9ec0095108eb1954e',1,'Track']]],
  ['getship_5fid_5f',['getShip_id_',['../classTrack.html#a4c1bb0e124261fd410d93eec99d3abe3',1,'Track']]],
  ['getspeed_5f',['getSpeed_',['../classTrack.html#a8aab7b0c5221d6236beb92b0ad554c95',1,'Track']]],
  ['gettime_5felapsed_5ffrom_5fcreation',['getTime_elapsed_from_creation',['../classTrack.html#ab5cc36e4aa55d39be683aa34c4467b97',1,'Track']]]
];
