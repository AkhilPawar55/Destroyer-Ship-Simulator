var searchData=
[
  ['check_5ffor_5fde_5fcorrelation',['check_for_de_correlation',['../classSimulator.html#a9a733b4a1449caf79866b958f8f66da4',1,'Simulator']]],
  ['correlate_5ftracks',['correlate_tracks',['../classSimulator.html#a40f86ccbed2665816b159d126a760781',1,'Simulator']]]
];
