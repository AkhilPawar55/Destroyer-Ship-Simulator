var searchData=
[
  ['setcategory_5f',['setCategory_',['../classTrack.html#a1f2f5a96df9b384d2ff9e20356854d7d',1,'Track']]],
  ['setcorrelated_5ftrack_5fid',['setCorrelated_track_id',['../classTrack.html#a472f63d140e24f6975804df267e2ff15',1,'Track']]],
  ['setdistance_5f',['setDistance_',['../classTrack.html#a8c037865f797ff36b5b76393d6d457d8',1,'Track']]],
  ['setidentity_5f',['setIdentity_',['../classTrack.html#ad31b88729ad4465ca171dd8695799004',1,'Track']]],
  ['setship_5fid_5f',['setShip_id_',['../classTrack.html#a14e193136d4b3ad6884146a4c25a7b45',1,'Track']]],
  ['setspeed_5f',['setSpeed_',['../classTrack.html#a791379f1d91b3498fd9594456cd3e760',1,'Track']]],
  ['settime_5felapsed_5ffrom_5fcreation',['setTime_elapsed_from_creation',['../classTrack.html#a67a38820f82ebecc8ddea366ac5fd070',1,'Track']]],
  ['simulator',['Simulator',['../classSimulator.html',1,'Simulator'],['../classSimulator.html#a031573bfcfe2e0f5c9539bcc1c7fc5d9',1,'Simulator::Simulator()']]],
  ['stop',['stop',['../classSimulator.html#a8a0ca0d13dcdd8b7bb205adc3326ad4d',1,'Simulator']]],
  ['sync_5faccess_5fmutex',['sync_access_mutex',['../classSimulator.html#aeb3e3b21bc68a17dd107c409ecac7f04',1,'Simulator']]]
];
